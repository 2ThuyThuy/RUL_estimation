const dataReport = {
    "name": "ThuyThuy",
    "email": "thuynguyen@gmail.com",
    "phone": "+(84) 123-423-3809",
    "now_date": "2019-10-12",
    "items": [
      {
        "unit": 200,
        "day_start": "2023/01/30",
        "operation": 120,
        "day_error": "2023/06/30",
        "reliability": "82%",
        "remaining": 50
      }
    ]
}
export default dataReport;

