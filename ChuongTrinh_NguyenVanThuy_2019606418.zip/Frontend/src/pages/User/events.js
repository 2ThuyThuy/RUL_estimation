const now = new Date();

export default [
  {
    title: "All Day Event very long title",
    allDay: true,
    start: new Date(2023, 6, 1),
    end: new Date(2023, 6, 1)
  },
  {
    title: "Long Event",
    color : 'blue',
    start: new Date(2023, 4, 7),
    end: new Date(2023, 4, 7)
  },
  {
    title: "All Day Event very long title",
    allDay: true,
    color: "orange",
    start: new Date(2023, 4, 1),
    end: new Date(2023, 4, 1)
  },
];
